from django.shortcuts import render
import pymysql
from django.http import HttpResponse

# Create your views here.
def login(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from dept")
    data=cur.fetchall()
    strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
    for i in data:
      strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
    strdata+= "</select>"
    context = {'data': strdata}
    return render(request,'TAC/Login.html', context)

def Signup(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from dept")
    data=cur.fetchall()
    strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
    for i in data:
      strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
    strdata+= "</select>"
    context = {'data': strdata}
    return render(request, 'TAC/Register.html', context)


def RegAction(request):

    t_dept=request.POST['dept']
    t_name=request.POST['name']
    t_email=request.POST['email']
    t_mobile=request.POST['mobile']
    t_address=request.POST['address']
    t_username=request.POST['username']
    t_password=request.POST['password']

    con = pymysql.connect(host='localhost', user='root', password='root', database='florida_atlantic_university')
    cur = con.cursor()
    cur.execute("Select * from member where dept='"+t_dept+"' and mobile='"+t_mobile+"' or dept='"+t_dept+"' and  email='"+t_email+"'");
    a = cur.fetchone()
    if a is not None:
        cur = con.cursor()
        cur.execute("select * from dept")
        data=cur.fetchall()
        strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
        for i in data:
            strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
        strdata+= "</select>"
        context = {'data': strdata,  'msg': 'Email id or Mobile Number Already Exist..!!'}
        return render(request, 'TAC/Register.html', context)
    else:
        cur1 = con.cursor()
        i = cur1.execute("insert into member values(null,'"+t_dept+"','"+t_name+"','"+t_email+"','"+t_mobile+"','"+t_address+"','"+t_username+"','"+t_password+"')")
        con.commit()
        if i > 0:
            cur = con.cursor()
            cur.execute("select * from dept")
            data=cur.fetchall()
            strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
            for i in data:
                strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
            strdata+= "</select>"
            context = {'data': strdata,  'msg': 'Registration Successful..!!'}
            return render(request, 'TAC/Register.html', context)
        else:
            context = {'msg': 'Registration Failed..!!'}
            return render(request, 'TAC/Register.html', context)


def LogAction(request):
    a_dept=request.POST['dept']
    uname=request.POST['username']
    passw=request.POST['password']
    con = pymysql.connect(host='localhost', user='root', password='root', database='florida_atlantic_university')
    cur = con.cursor()
    cur.execute("Select * from member where dept='"+a_dept+"' and username='"+uname+"' and  password='"+passw+"'");
    data=cur.fetchone()
    if data is not None:
        request.session['id']=data[0]
        request.session['email']=data[3]
        request.session['mobile']=data[4]
        request.session['dept']=data[1]
        return render(request, 'TAC/TAC_Home.html')
    else:
        con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
        cur = con.cursor()
        cur.execute("select * from dept")
        data=cur.fetchall()
        strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
        for i in data:
            strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
        strdata+= "</select>"
        context = {'data': strdata, 'msg': 'Login Failed..!!'}
        return render(request, 'TAC/Login.html', context)

def Home(request):
    return render(request, 'TAC/TAC_Home.html')

def ViewResume(request):
    app_id=request.GET['app_id']
    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("select resume from apply_job where id='"+app_id+"'")
    file=cur.fetchone()[0]
    cur.close()

    response = HttpResponse(file, content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="Resume.pdf"'
    return response

def AssignTask(request):
    app_id=request.GET['appid']
    request.session['appid']=app_id
    return render(request, 'TAC/AssignTask.html')

def ForwardTaskAction(request):
    a_id=request.POST['aid']
    des=request.POST['desc']

    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    i = cur.execute("update apply_job set task='"+des+"',a_status='Assigned' where id='"+a_id+"'")
    con.commit()
    dept=request.session['dept']
    cur1=con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id and applicant.dept='"+dept+"')INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th><th>Salary</th>" \
            "<th>Date of Application</th><th>Resume</th><th>Assign Task</th>" \
            "</tr></thead>"
    k=0
    for i in data:
        k=k+1
        astatus=i[8]
        if astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?appid="+str(i[0])+"'>View</a></td>" \
                  "<td><a href='/TAC/AssignTask?appid="+str(i[0])+"'>Assign Task</a></td></tr></tbody>"
        else:
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?appid="+str(i[0])+"'>View</a></td>" \
                  "<td>Task Assigned</td></tr></tbody>"

    context = {'data': strdata, 'msg' : 'Task Assigned And Forwarded To Admin'}
    return render(request, 'Admin/ViewApplicants.html', context)


def AllTasks(request):
    dept = request.session['dept']
    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id and applicant.dept='"+dept+"')INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Assigned Task</th>" \
            "</tr></thead>"
    k=0
    for i in data:
        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td><textarea cols='30' rows='5' readonly>"+str(i[6])+"</textarea></td></tr></tbody>"
    context = {'data': strdata,}
    return render(request, 'TAC/AllTasks.html', context)

def AllTAPerform(request):
    dept = request.session['dept']
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur1 = con.cursor()
    cur1.execute("select * from performance p, applicant a where p.ta_id=a.id and a.dept='"+dept+"'")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Department</th><th>TA Email</th><th>TA Mobile</th><th>Subject</th><th>Performance</th><th>Rate on Scale of 10</th>" \
            "<th>Date</th> </tr></thead>"
    k=0
    for i in data:

        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[8])+"</td><td>"+str(i[10])+"</td><td>"+str(i[11])+"</td>" \
                "<td>"+str(i[3])+"</td><td>"+str(i[4])+"</td><td>"+str(i[5])+"</td><td>"+str(i[6])+"</td></tr></tbody>"
    context={'data':strdata}
    return render(request,'TAC/ViewTAPerform.html',context)


# def ForwardAssignment(request):
#     a_id=request.GET['id']
#     request.session['a_id']=a_id
#     return render(request, 'Admin/AddAssignment.html')

def VerifyAssignment(request):

    a_id= request.GET['id']
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from apply_job where id='"+a_id+"'")
    data=cur.fetchone()
    task=data[6]
    ans=data[7]
    exp_date=data[9]
    request.session['a_id']=a_id
    request.session['task']=task
    request.session['ans']=ans
    request.session['exp_date']=exp_date

    return render(request,'TAC/VerifyAssignment.html')

def ViewApplicaiton(request):

    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th><th>Recommend_Status</th> </tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]
        r_status=i[10]
        #print(f"==========> {r_status}")
        if r_status != 'Recommended':
            continue
        #print(r_status)

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
            #print("=====> 1 <=========")
        
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Forwarded To TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
            #print("=====> 2 <=========")
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
            #print("=====> 3 <=========")
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='/TAC/AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='/TAC/DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td><td>Recommended by Department Staff</td></tr></tbody>"
                #print(strdata)
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
                #print("=====> 5 <=========")
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td><td>Recommended by Department Staff</td></tr></tbody>"
                 #print("=====> 6 <=========")
    context = {'data': strdata}
    return render(request, 'TAC/ViewApplicants.html', context)


def DeclineVacancy(request):
    a_id=request.GET['id']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set status='Declined' where id='"+a_id+"'")
    con.commit()
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th> <th> Recommend Status </th></tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]
        r_status = i[10]
        if r_status != 'Recommended':
            continue

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Forwarded To TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='/TAC/AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='/TAC/DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td><td>Recommended by Department Staff</td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td><td>Recommended by Department Staff</td></tr></tbody>"                                                                                                                               "<a href='DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td></tr></tbody>"
        context = {'data': strdata}
    return render(request, 'TAC/ViewApplications.html', context)

def AcceptVacancy(request):
    a_id=request.GET['id']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set status='Accepted' where id='"+a_id+"'")
    con.commit()
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th><th> Recommend Status</th></tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]
        r_status=i[10]

        if r_status != 'Recommended':
            continue

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Forwarded To TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td><td>Recommended by Department Staff</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='/TAC/AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='/TAC/DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td><td>Recommended by Department Staff</td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='/TAC/VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td><td>Recommended by Department Staff</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[3])+"</td><td><a href='/TAC/ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href=/TAC/'VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td><td>Recommended by Department Staff</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'TAC/ViewApplicants.html', context)


