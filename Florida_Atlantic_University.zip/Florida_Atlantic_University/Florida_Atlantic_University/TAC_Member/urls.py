from django.urls import path
from TAC_Member import views

urlpatterns= [
    path('login', views.login),
    path('Signup', views.Signup),
    path('RegAction', views.RegAction),
    path('LogAction', views.LogAction),
    path('Home', views.Home),
    path('ViewResume', views.ViewResume),
    path('AssignTask', views.AssignTask),
    path('ForwardTaskAction', views.ForwardTaskAction),
    path('AllTasks', views.AllTasks),
    path('AllTAPerform', views.AllTAPerform),
    # path('ForwardAssignment',views.ForwardAssignment),
    path('VerifyAssignment',views.VerifyAssignment),
    path('DeclineVacancy', views.DeclineVacancy),
    path('AcceptVacancy', views.AcceptVacancy),
    path('ViewApplications', views.ViewApplicaiton),
]

