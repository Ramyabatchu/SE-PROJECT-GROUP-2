from django.apps import AppConfig


class InstructorConfig(AppConfig):
    name = 'Instructor'
