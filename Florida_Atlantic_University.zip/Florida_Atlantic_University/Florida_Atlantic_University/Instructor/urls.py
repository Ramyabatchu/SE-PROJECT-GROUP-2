from django.urls import path
from Instructor import views

urlpatterns= [
    path('login', views.login),
    path('LogAction', views.LogAction),
    path('AddPerformance', views.AddPerformance),
    path('GetTADetails', views.GetTADetails),
    path('AddTAPerformance', views.AddTAPerformance),
    path('ViewPerformance', views.ViewPerformance),
    path('Delete', views.Delete),
    path('Instructor_Home',views.instructorhome)
]
