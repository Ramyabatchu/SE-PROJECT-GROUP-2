from django.shortcuts import render
import pymysql
# Create your views here.
def login(request):

    return render(request,'Instructor/Login.html')

def instructorhome(request):
    return render(request, 'Instructor/Instructor_Home.html')


def LogAction(request):

    username = request.POST['username']
    password = request.POST['password']

    if username == 'instructor' and password == 'instructor':
        return render(request, 'Instructor/Instructor_Home.html')
    else:
        context = {'data': 'Login Failed'}
        return render(request, 'Instructor/Login.html', context)

def AddPerformance(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from dept")
    data=cur.fetchall()
    strdata=" <select class='custom-select border-1 px-4' name='dept'  style='height: 47px; width:500px' required=''> <option selected></option>"
    for i in data:
      strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
    strdata+= "</select>"
    context = {'data': strdata}
    return render(request,'Instructor/AddPerformance.html', context)

def GetTADetails(request):

    deptart = request.POST['dept']
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from apply_job aj,applicant a where a.dept='"+deptart+"' and aj.status='Accepted' and a.id=aj.ta_id")
    data=cur.fetchall()
    strdata=" <select class='custom-select border-1 px-4' name='ta_id'  style='height: 60px; width:648px;' required=''> <option selected></option>"
    for i in data:
      strdata+= "<option value='"+str(i[1])+"'>"+str(i[14])+"</option>"
    strdata+= "</select>"
    context = {'data': strdata,'dept': deptart}
    return render(request,'Instructor/AddPerformance2.html', context)

def AddTAPerformance(request):
    #print(request.POST)
    #print("========================")
    t_dept=request.POST['dept']
    t_id=request.POST['ta_id']
    #t_id=request.session
    t_subject=request.POST['subject']
    t_performance=request.POST['performance']
    t_scale=request.POST['scale']
    t_date=request.POST['date']

    con = pymysql.connect(host='localhost', user='root', password='root', database='florida_atlantic_university')
    cur = con.cursor()
    a= cur.execute("insert into performance values(null,'"+t_dept+"','"+t_id+"','"+t_subject+"','"+t_performance+"','"+t_scale+"','"+t_date+"')");
    con.commit()
    if a > 0:
        con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
        cur = con.cursor()
        cur.execute("select * from dept")
        data=cur.fetchall()
        strdata=" <select class='custom-select border-1 px-4' name='dept'  style='height: 47px; width:500px' required=''> <option selected></option>"
        for i in data:
            strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
        strdata+= "</select>"

        context = {'data': strdata, 'msg': 'Performance Added Successfully..!!'}
        return render(request, 'Instructor/AddPerformance.html', context)
    else:
        con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
        cur = con.cursor()
        cur.execute("select * from dept")
        data=cur.fetchall()
        strdata=" <select class='custom-select border-1 px-4' name='dept'  style='height: 47px; width:500px' required=''> <option selected></option>"
        for i in data:
            strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
        strdata+= "</select>"

        context = {'data': strdata, 'msg': 'Performance Not Added..!!'}
        return render(request, 'Instructor/AddPerformance.html', context)

def ViewPerformance(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur1 = con.cursor()
    cur1.execute("select * from performance p, applicant a where p.ta_id=a.id")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Department</th><th>TA Email</th><th>TA Mobile</th><th>Subject</th><th>Performance</th><th>Rate on Scale of 10</th>" \
            "<th>Date</th><th>Action</th>  </tr></thead>"
    k=0
    for i in data:

        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[8])+"</td><td>"+str(i[10])+"</td><td>"+str(i[11])+"</td>" \
                "<td>"+str(i[3])+"</td><td>"+str(i[4])+"</td><td>"+str(i[5])+"</td><td>"+str(i[6])+"</td>" \
                    "<td><a href='Delete?app_id="+str(i[0])+"'>Delete</a></td></tr></tbody>"

    context={'data':strdata}
    return render(request,'Instructor/ViewPerformance.html',context)

def Delete(request):
    app_id=request.GET['app_id']
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur1 = con.cursor()
    i = cur1.execute("delete from performance where id='"+app_id+"'")
    con.commit()
    if i >0:
        con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
        cur1 = con.cursor()
        cur1.execute("select * from performance p, applicant a where p.ta_id=a.id")
        data=cur1.fetchall()
        strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Department</th><th>TA Email</th><th>TA Mobile</th><th>Subject</th><th>Performance</th><th>Rate on Scale of 10</th>" \
            "<th>Date</th><th>Action</th>  </tr></thead>"
        k=0
        for i in data:

            k=k+1
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[8])+"</td><td>"+str(i[10])+"</td><td>"+str(i[11])+"</td>" \
                "<td>"+str(i[3])+"</td><td>"+str(i[4])+"</td><td>"+str(i[5])+"</td><td>"+str(i[6])+"</td>" \
                    "<td><a href='Delete?app_id="+str(i[0])+"'>Delete</a></td></tr></tbody>"

        context={'data':strdata, 'msg':'Deleted Successfully...!!'}
        return render(request,'Instructor/ViewPerformance.html',context)
    else:
        con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
        cur1 = con.cursor()
        cur1.execute("select * from performance p, applicant a where p.ta_id=a.id")
        data=cur1.fetchall()
        strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Department</th><th>TA Email</th><th>TA Mobile</th><th>Subject</th><th>Performance</th><th>Rate on Scale of 10</th>" \
            "<th>Date</th><th>Action</th>  </tr></thead>"
        k=0
        for i in data:

            k=k+1
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[8])+"</td><td>"+str(i[10])+"</td><td>"+str(i[11])+"</td>" \
                "<td>"+str(i[3])+"</td><td>"+str(i[4])+"</td><td>"+str(i[5])+"</td><td>"+str(i[6])+"</td>" \
                    "<td><a href='Delete?app_id="+str(i[0])+"'>Delete</a></td></tr></tbody>"

        context={'data':strdata, 'msg':'Delete Failed...!!'}
        return render(request,'Instructor/ViewPerformance.html',context)





