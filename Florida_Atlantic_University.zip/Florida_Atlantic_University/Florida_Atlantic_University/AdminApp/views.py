from django.shortcuts import render
import pymysql
from django.http import HttpResponse
# Create your views here.


def index(request):
    return render(request, 'Admin/index.html')


def login(request):
    return render(request, 'Admin/Login.html')


def adminaction(request):
    username = request.POST.get('username')
    password = request.POST.get('password')

    if username == 'Admin' and password == 'Admin':
        return render(request, 'Admin/AdminHome.html')
    else:
        context = {'data': 'Login Failed'}
        return render(request, 'Admin/Login.html', context)

def AdminHome(request):
    return render(request, 'Admin/AdminHome.html')

def AddDept(request):
    return render(request, 'Admin/AddDept.html')

def AddDeptAction(request):

    department = request.POST['dept']
    con = pymysql.connect(host='localhost', user='root', password='root', database='florida_atlantic_university')
    cur = con.cursor()
    cur.execute("select * from dept where name='"+department+"'");
    a = cur.fetchone()
    if a is not None:
        context = {'data': 'Department Already Added'}
        return render(request, 'Admin/AddDept.html', context)
    else:
        cur1 = con.cursor()
        i = cur1.execute("insert into dept values('"+department+"')")
        con.commit()
        if i > 0:
            context = {'data': 'Department Added Successfully..!!'}
            return render(request, 'Admin/AddDept.html', context)
        else:
            context = {'data': 'Department Adding Failed...!!'}
            return render(request, 'Admin/AddDept.html', context)
def ViewDept(request):

    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("select * from dept")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th><th>Department</th><th>Delete</th></tr></thead>"
    k=0
    for i in data:
        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[0])+"</td><td><a href='/delete?dname="+str(i[0])+"'>Delete</a></td></tr></tbody>"
        context = {'data': strdata}
    return render(request, 'Admin/ViewDept.html', context)

def delete(request):
    dept=request.GET['dname']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("delete from dept where name='"+dept+"'")
    cur1 = con.cursor()
    con.commit()
    cur1.execute("select * from dept")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th><th>Department</th><th>Delete</th></tr></thead>"
    k=0
    for i in data:
        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[0])+"</td><td><a href='/delete?dname="+str(i[0])+"'>Delete</a></td></tr></tbody>"
        context = {'data': strdata}
    return render(request, 'Admin/ViewDept.html', context)

def PostApplication(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from dept")
    data=cur.fetchall()
    strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
    for i in data:
      strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
    strdata+= "</select>"
    context = {'data': strdata}
    return render(request, 'Admin/PostVacancy.html', context)

def AddTAVacancyAction(request):
    depart=request.POST['dept']
    v_name=request.POST['vname']
    experience=request.POST['exp']
    #salary=request.POST['salary']
    description=request.POST['desc']
    con = pymysql.connect(host='localhost', user='root', password='root', database='florida_atlantic_university')
    cur = con.cursor()
    cur.execute("Select * from vacancy where dept='"+depart+"' and job_name='"+v_name+"'")
    a = cur.fetchone()
    if a is not None:
        cur1 = con.cursor()
        cur1.execute("select * from dept")
        data=cur1.fetchall()
        strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
        for i in data:
            strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
        strdata+= "</select>"
        context = {'data': strdata, 'msg': 'Job Vacancy Already Exist..!!'}
        return render(request, 'Admin/PostVacancy.html', context)
    else:
        cur1 = con.cursor()
        #i = cur1.execute("insert into vacancy(dept,job_name,experience,description) values('"+depart+"','"+v_name+"','"+experience+"','"+"','"+description+"')")
        i = cur1.execute("insert into vacancy(dept,job_name,experience,description) values(%s, %s, %s, %s)", (depart, v_name, experience, description))

        con.commit()
        if i > 0:
            cur.execute("select * from dept")
            data=cur.fetchall()
            strdata=" <select class='custom-select border-0 px-4' name='dept'  style='height: 47px;' required=''> <option selected></option>"
            for i in data:
                strdata+= "<option value='"+str(i[0])+"'>"+str(i[0])+"</option>"
            strdata+= "</select>"
            context = {'data': strdata, 'msg':'Vacancy Posted Successfully..!!'}
            return render(request, 'Admin/PostVacancy.html', context)
        else:
            context = {'data': 'Vacancy Posting Failed...!!'}
            return render(request, 'Admin/PostVacancy.html', context)


def ViewApplicaiton(request):

    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            " <th>Resume</th> <th>Assignment</th><th>Assign Task</th><th>Recommend</th> </tr></thead>"  #changed here
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]
        r_status=i[10]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td><a href='/AssignTask?appid="+str(i[0])+"'>Assign Task</a></td><td>To be Assigned</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Task Assigned</td><td>To be Solved</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Task Assigned</td><td>To be Solved</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved' and r_status!='Recommended':   #changed here
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td><a href='Recommend?id="+str(i[0])+"'>Recommend to TAC</a></td></tr></tbody>"
            elif r_status=='Recommended':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td>Recommended</td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td>To be Solved</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[15])+"</td><td>"+str(i[16])+"</td><td>"+str(i[13])+"</td>" \
                "<td>"+str(i[22])+"</td><td>"+str(i[23])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td><td>Recommended</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)

def ForwardAssignment(request):
    a_id=request.GET['id']
    request.session['a_id']=a_id
    return render(request, 'Admin/AddAssignment.html')

def AddTaskDateAction(request):
    a_id=request.POST['a_id']
    date=request.POST['date']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set a_status='Assigned',exp_date='"+date+"' where id='"+a_id+"'")
    con.commit()
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Description</th><th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th></tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Loading...</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)




def AcceptVacancy(request):
    a_id=request.GET['id']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set status='Accepted' where id='"+a_id+"'")
    con.commit()
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th></tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Loading...</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)

def DeclineVacancy(request):
    a_id=request.GET['id']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set status='Declined' where id='"+a_id+"'")
    con.commit()
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Date of Apply</th> <th>Resume</th> <th>Assignment</th> <th>Status</th></tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td>Loading..</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Loading...</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Loading...</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td><a href='AcceptVacancy?id="+str(i[0])+"'>Accept</a> (OR)" \
                 "<a href='DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Loading..</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td></tr></tbody>"                                                                                                                               "<a href='DeclineVacancy?id="+str(i[0])+"'>Decline</a> </td></tr></tbody>"
        context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)

def VerifyAssignment(request):

    a_id= request.GET['id']
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("select * from apply_job where id='"+a_id+"'")
    data=cur.fetchone()
    task=data[6]
    ans=data[7]
    exp_date=data[9]
    request.session['a_id']=a_id
    request.session['task']=task
    request.session['ans']=ans
    request.session['exp_date']=exp_date

    return render(request,'Admin/VerifyAssignment.html')

def ViewAllTA(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur1 = con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON  apply_job.ta_id = applicant.id and apply_job.status='Accepted')INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            "<th>Description</th><th>Date of Apply</th> <th>Resume</th><th>Status</th></tr></thead>"
    k=0
    for i in data:

        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td>"+str(i[22])+"</td><td>"+str(i[3])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>"+str(i[5])+"</td></tr></tbody>"
    context={'data':strdata}
    return render(request,'Admin/ViewAllTA.html',context)

def AViewTAPerform(request):
    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur1 = con.cursor()
    cur1.execute("select * from performance p, applicant a where p.ta_id=a.id")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Department</th><th>TA Email</th><th>TA Mobile</th><th>Subject</th><th>Performance</th><th>Rate on Scale of 10</th>" \
            "<th>Date</th> </tr></thead>"
    k=0
    for i in data:

        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[8])+"</td><td>"+str(i[10])+"</td><td>"+str(i[11])+"</td>" \
                "<td>"+str(i[3])+"</td><td>"+str(i[4])+"</td><td>"+str(i[5])+"</td><td>"+str(i[6])+"</td></tr></tbody>"
    context={'data':strdata}
    return render(request,'Admin/AViewTAPerform.html',context)


def ViewResume(request):
    appid=request.GET['app_id']
    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("select resume from apply_job where id='"+appid+"'")
    file=cur.fetchone()[0]
    cur.close()

    response = HttpResponse(file, content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="Resume.pdf"'
    return response

def AllTasks(request):
    dept = request.session['dept']
    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    cur.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id and applicant.dept='"+dept+"')INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Assigned Task</th>" \
            "</tr></thead>"
    k=0
    for i in data:
        k=k+1
        strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td><textarea cols='30' rows='5' readonly>"+str(i[6])+"</textarea></td></tr></tbody>"
    context = {'data': strdata,}
    return render(request, 'Admin/AllTasks.html', context)

def AssignTask(request):
    app_id=request.GET['appid']
    request.session['appid']=app_id
    return render(request, 'Admin/AssignTask.html')

def ForwardTaskAction(request):
    a_id=request.POST['aid']
    des=request.POST['desc']

    con=pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur=con.cursor()
    i = cur.execute("update apply_job set task='"+des+"',a_status='Admin' where id='"+a_id+"'")
    con.commit()
    
    # dept=request.session['dept']
    cur1=con.cursor()
    cur1.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur1.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            " <th>Resume</th> <th>Assignment</th><th>Assign Task</th> </tr></thead>"
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td><a href='/AssignTask?appid="+str(i[0])+"'>Assign Task</a></td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Task Assigned</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Task Assigned</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)


def Recommend(request):
    a_id=request.GET['id']

    con = pymysql.connect(host="localhost",user="root",password="root",database="florida_atlantic_university")
    cur = con.cursor()
    cur.execute("update apply_job set recommend_status='Recommended' where id='"+a_id+"'")
    con.commit()
    cur=con.cursor()
    cur.execute("SELECT * FROM ((apply_job INNER JOIN applicant ON apply_job.ta_id = applicant.id )INNER JOIN vacancy ON apply_job.v_id = vacancy.id)")
    data=cur.fetchall()
    strdata="<table  id='example' class='table table-striped table-bordered' style='width:100%'><thead><tr><th>Sr.No</th>" \
            "<th>Applicant Email</th><th>Applicant Mobile</th><th>Department</th><th>Subject</th><th>Experience</th>" \
            " <th>Resume</th> <th>Assignment</th><th>Assign Task</th><th>Recommend</th> </tr></thead>"  #changed here
    k=0
    for i in data:
        status = i[5]
        task = i[6]
        astatus = i[8]
        recommend_status=i[10]

        k=k+1
        if task == 'waiting' and astatus == 'waiting':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>No Assignment Found</td><td><a href='/AssignTask?appid="+str(i[0])+"'>Assign Task</a></td><td>To be Assigned</td></tr></tbody>"
        elif astatus == 'Admin':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='ForwardAssignment?id="+str(i[0])+"'>Forward To TA</a></td><td>Task Assigned</td><td>To be Solved</td></tr></tbody>"
        elif astatus =='Assigned':
            strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td>Assignment Sent to TA</td><td>Task Assigned</td><td>To be Solved</td></tr></tbody>"
        else:
            if status =='waiting' and astatus =='Solved' and recommend_status!='Recommended':   #changed here
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td><a href='/ViewApplicaiton'>Recommend to TAC</a></td></tr></tbody>"
            elif recommend_status=="Recommended":
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td>Recommended</td></tr></tbody>"
            elif status =='waiting':
                strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>Task Assigned</td><td>To be solved</td></tr></tbody>"
            else:
                 strdata+="<tbody><tr><td>"+str(k)+"</td><td>"+str(i[13])+"</td><td>"+str(i[14])+"</td><td>"+str(i[19])+"</td>" \
                "<td>"+str(i[20])+"</td><td>"+str(i[21])+"</td><td><a href='ViewResume?app_id="+str(i[0])+"'>View Resume</a></td><td><a href='VerifyAssignment?id="+str(i[0])+"'>Verify Assignment</a></td><td>"+str(i[5])+"</td><td>To be solved</td></tr></tbody>"
    context = {'data': strdata}
    return render(request, 'Admin/ViewApplicants.html', context)

